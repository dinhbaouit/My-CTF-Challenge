<?php

$salt = "Yahhooooo, DD Family aanjsjbvn";

?>
