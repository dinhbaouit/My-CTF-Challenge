<?php
include "config.php";
class LogRequest {
    const LOGGINGDIR = '/var/www/html/logs/';
    private $remote_addr;

    public function __construct($input) {
	global $salt;
        $this-> remote_addr = sha1($_SERVER['REMOTE_ADDR'].$salt);

        foreach ($input as $field => $c) {
            $this->$field = $c++;
        }
    }

    public function __destruct() {
        file_put_contents(
            self::LOGGINGDIR . $this->remote_addr,
            var_export(get_object_vars($this), true), FILE_APPEND
        );
    }
}

if(isset($_GET['debug']))
{
    show_source(__FILE__);
    die("...");
}
if(isset($_GET['host']) && !empty($_GET['host']))
{
    $host = escapeshellarg($_GET['host']);
    system("ping -c 4 ".$host);
}
?>
<!DOCTYPE html>
<html lang="en-US">
<head>
<title>HTML Forms</title>
</head>
<body>

<form action="/index.php">
  <br>
  Ping: <br>
  <input type="text" name="host" value="127.0.0.1"><br><br>
  <input type="submit" value="Submit">
</form>

</body>
<?php 
$req_log = new LogRequest($_GET);
?>
<!-- ?debug-->