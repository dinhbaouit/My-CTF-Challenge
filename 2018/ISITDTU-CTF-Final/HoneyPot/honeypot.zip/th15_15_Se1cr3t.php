<?php

$flag = "ISITDTU{28d541b9700ba5feab6ea39474ececae2331e3d0}"

?>
